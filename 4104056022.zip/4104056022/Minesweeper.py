# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from __future__ import print_function
from __future__ import division 
from shutil import copyfile
import random
import time
#read the file and create a map
def mapcreate(filename,row,col):
    map=[[0 for a in range(col)]for b in range(row)]
    with open(filename,'r') as f:
        c=0
        for line in f:
            line=line.split(',')
            for d in range(col):
                map[c][d]=int(line[d])
            c+=1
    return map
#create a map for the mine count
def minecount(map,row,col):
    for a in range(row):
        for b in range(col):
            if map[a][b]==-1:
                if a!=0 and a!=row-1:
                    if b!=0 and b!=col-1:
                        for c in range(a-1,a+2):
                            for d in range(b-1,b+2):
                                if map[c][d]!=-1:
                                    '''
                                    print(str(c))
                                    print(str(d))
                                    '''
                                    map[c][d]+=1
                    elif b==0:
                        for c in range(a-1,a+2):
                            for d in range(b,b+2):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                    else:
                        for c in range(a-1,a+2):
                            for d in range(b-1,b+1):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                elif a==0:
                    if b!=0 and b!=col-1:
                        for c in range(a,a+2):
                            for d in range(b-1,b+2):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                    elif b==0:
                        for c in range(a,a+2):
                            for d in range(b,b+2):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                    else:
                        for c in range(a,a+2):
                            for d in range(b-1,b+1):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                else:
                    if b!=0 and b!=col-1:
                        for c in range(a-1,a+1):
                            for d in range(b-1,b+2):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                    elif b==0:
                        for c in range(a-1,a+1):
                            for d in range(b,b+2):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
                    else:
                        for c in range(a-1,a+1):
                            for d in range(b-1,b+1):
                                if map[c][d]!=-1:
                                    map[c][d]+=1
    return map
#check the surrounding blocks of the open block
def surrounding_check(map,row,col,c_row,c_col):
    if map[c_row][c_col]==0:
        for a in range(c_row-1,c_row+2):
            for b in range(c_col-1,c_col+2):
                if a>=0 and a<row:
                    if b>=0 and b<col:
                        map[a][b]=-2
    return map
#check the user's status of the game
def wingame(map,row,col):
    for a in range(row):
        for b in range(col):
            if map[a][b]>=0:
                return False
    return True
#count the point of the user
def pointscount(map,row,col):
    points=0
    if wingame(map,row,col):
        return 30
    for a in range(row):
        for b in range(col):
            if map[a][b]==-2:
                points+=1
    return (30*points)/(row*col)
#print the map
def mapprint(map,presentmap,row,col):
    for a in range(row):
        for b in range(col):
            if map[a][b]==-2:
                print(" "+str(presentmap[a][b])+" ",end="")
            else:
                print(" ■ ",end="")  
        print("")
#minesweeper AI
def ai(filename,standardfile,row,col):
    life=2
    map=mapcreate(filename,row,col)
    map=minecount(map,row,col)
    with open ("hw1/"+standardfile+".txt",'w') as f:
        for a in range(row):
            for b in range(col):
                if b!=col-1:
                    f.write(str(map[a][b])+',')
                else:
                    f.write(str(map[a][b]))
            f.write("\n")
    presentmap=mapcreate("hw1/"+standardfile+".txt",row,col)
    copyfile("hw1/"+standardfile+".txt","hw1/play.txt")
    while True:
        map=mapcreate("hw1/play.txt",row,col)
        mapprint(map,presentmap,row,col)
        time.sleep(3)
        if wingame(map,row,col):
            print("Computer wins! Computer's points:"+str(pointscount(map,row,col)))
            with open("hw1/result.txt",'w') as f:
                f.write("Computer wins! Computer's points:"+str(pointscount(map,row,col)))    
            return pointscount(map,row,col)
        while True:
            random.seed(time.time())
            r=random.randint(0,row-1)
            c=random.randint(0,col-1)
            if map[r][c]>=0:
                print("Computer chooses the "+str(r+1)+" row.")
                print("Computer chooses the "+str(c+1)+" column.")
                break
        if map[r][c]==-1:
            if life>0:
                life-=1
                map[r][c]=-2
                print("Computer loses one life!")
            else:
                print("Game over! Computer's points:"+str(pointscount(map,row,col)))
                with open("hw1/result.txt",'w') as f:
                    f.write("Game over! Computer's points:"+str(pointscount(map,row,col)))     
                return pointscount(map,row,col)
        else:
            map[r][c]=-2
            surrounding_check(map,row,col,r,c)
            with open ("hw1/play.txt",'w') as f:
                for a in range(row):
                    for b in range(col):
                        if b!=col-1:
                            f.write(str(map[a][b])+',')
                        else:
                            f.write(str(map[a][b]))
                    f.write("\n")
    
#initiate a game
def minesweeper(filename,standardfile,row,col):
    map=mapcreate(filename,row,col)
    map=minecount(map,row,col)
    with open ("hw1/"+standardfile+".txt",'w') as f:
        for a in range(row):
            for b in range(col):
                if b!=col-1:
                    f.write(str(map[a][b])+',')
                else:
                    f.write(str(map[a][b]))
            f.write("\n")
    presentmap=mapcreate("hw1/"+standardfile+".txt",row,col)
    copyfile("hw1/"+standardfile+".txt","hw1/play.txt")
    while True:
        map=mapcreate("hw1/play.txt",row,col)
        mapprint(map,presentmap,row,col)
        if wingame(map,row,col):
            print("You win! Your points:"+str(pointscount(map,row,col)))
            with open("hw1/result.txt",'w') as f:
                f.write("You win! Your points:"+str(pointscount(map,row,col)))    
            break
        r=input("Please enter the row of the box(1~9):")-1
        c=input("Please enter the coulumn of the box(1~9):")-1
        if map[r][c]==-1:
            print("Game over! Your points:"+str(pointscount(map,row,col)))
            with open("hw1/result.txt",'w') as f:
                f.write("Game over! Your points:"+str(pointscount(map,row,col)))     
            break
        else:
            map[r][c]=-2
            with open ("hw1/play.txt",'w') as f:
                for a in range(row):
                    for b in range(col):
                        if b!=col-1:
                            f.write(str(map[a][b])+',')
                        else:
                            f.write(str(map[a][b]))
                    f.write("\n")
if __name__ =='__main__':
    #play by computer
    #'''
    points=0
    points+=ai("hw1/data01.txt","standardfile01",9,9)
    copyfile("hw1/result.txt","hw1/AI1.txt")
    points+=ai("hw1/data02.txt","standardfile02",9,9)
    copyfile("hw1/result.txt","hw1/AI2.txt")
    points+=ai("hw1/data03.txt","standardfile03",9,9)
    copyfile("hw1/result.txt","hw1/AI3.txt")
    points+=ai("hw1/data04.txt","standardfile04",9,9)
    copyfile("hw1/result.txt","hw1/AI4.txt")
    points+=ai("hw1/data05.txt","standardfile05",9,9)
    copyfile("hw1/result.txt","hw1/AI5.txt")
    points/=5
    with open("hw1/AI average points.txt",'w') as f:
        f.write("AI average points: "+str(points))
    #'''
    #play by user
    '''
    minesweeper("hw1/data01.txt","standardfile01",9,9)
    minesweeper("hw1/data02.txt","standardfile02",9,9)
    minesweeper("hw1/data03.txt","standardfile03",9,9)
    minesweeper("hw1/data04.txt","standardfile04",9,9)
    minesweeper("hw1/data05.txt","standardfile05",9,9)
    '''
    